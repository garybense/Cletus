import { useEffect, useState } from "react";
import {
  Bot,
  Gauge,
  Inbox,
  Landmark,
  Menu,
  Moon,
  Pause,
  Play,
  Shield,
  Sun,
  Terminal,
  Workflow,
} from "lucide-react";
import { Toaster } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useHomestead } from "@/lib/cletus/store";
import { formatCredits, formatUptime, stateLabel, tierLabel } from "@/lib/cletus/format";
import type { ViewId } from "@/lib/cletus/types";
import { cn } from "@/lib/utils";
import { ColonyView } from "./colony-view";
import { DecreeBar } from "./decree-bar";
import { InboxView } from "./inbox-view";
import { LogsView } from "./logs-view";
import { OverviewView } from "./overview-view";
import { PolicyView } from "./policy-view";
import { StatusDot, agentTone, tierTone } from "./status";
import { TreasuryView } from "./treasury-view";
import { WorkView } from "./work-view";

const NAV: Array<{ id: ViewId; label: string; icon: typeof Gauge }> = [
  { id: "overview", label: "Overview", icon: Gauge },
  { id: "treasury", label: "Treasury", icon: Landmark },
  { id: "work", label: "Work", icon: Workflow },
  { id: "colony", label: "Colony", icon: Bot },
  { id: "inbox", label: "Inbox", icon: Inbox },
  { id: "logs", label: "Logs", icon: Terminal },
  { id: "policy", label: "Policy", icon: Shield },
];

const MOBILE_PRIMARY: ViewId[] = ["overview", "work", "colony", "inbox"];

export function MissionApp() {
  const view = useHomestead((s) => s.view);
  const setView = useHomestead((s) => s.setView);
  const paused = useHomestead((s) => s.paused);
  const togglePaused = useHomestead((s) => s.togglePaused);
  const toggleSleep = useHomestead((s) => s.toggleSleep);
  const vitals = useHomestead((s) => s.vitals);
  const now = useHomestead((s) => s.now);
  const inboxOpen = useHomestead((s) => s.inbox.filter((m) => m.status !== "done").length);
  const [moreOpen, setMoreOpen] = useState(false);

  useEffect(() => {
    useHomestead.getState().hydrate();
    const id = window.setInterval(() => {
      useHomestead.getState().tick();
    }, 2000);
    return () => window.clearInterval(id);
  }, []);

  const title = NAV.find((n) => n.id === view)?.label ?? "Overview";

  return (
    <TooltipProvider delayDuration={200}>
      <div id="mission-root" className="min-h-dvh bg-background text-foreground">
        <div className="mx-auto flex min-h-dvh max-w-7xl">
          <aside className="sticky top-0 hidden h-dvh w-56 shrink-0 flex-col border-r border-border px-3 py-5 md:flex">
            <Brand />
            <nav className="mt-8 flex flex-1 flex-col gap-1" aria-label="Sections">
              {NAV.map((item) => (
                <NavButton
                  key={item.id}
                  item={item}
                  active={view === item.id}
                  onSelect={setView}
                  badge={item.id === "inbox" && inboxOpen > 0 ? inboxOpen : undefined}
                />
              ))}
            </nav>
            <p className="px-2 text-xs leading-relaxed text-muted-foreground">
              Simulated homestead. Live Cletus stays on your machine.
            </p>
          </aside>

          <div className="flex min-w-0 flex-1 flex-col">
            <header className="sticky top-0 z-30 border-b border-border bg-background/95 px-4 py-3 backdrop-blur-sm md:px-6">
              <div className="flex items-center gap-3">
                <div className="md:hidden">
                  <Brand compact />
                </div>
                <div className="min-w-0 flex-1">
                  <h1 className="font-display text-xl font-medium tracking-tight md:text-2xl">{title}</h1>
                  <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                    <span className="inline-flex items-center gap-1.5">
                      <StatusDot tone={agentTone(vitals.state)} pulse={vitals.state === "running"} />
                      {stateLabel(vitals.state)}
                    </span>
                    <span className="tabular-nums">{formatUptime(vitals.startedAt, now)}</span>
                    <span className="hidden sm:inline">{vitals.model}</span>
                    <span className="tabular-nums">{formatCredits(vitals.creditsCents)}</span>
                    <Badge variant={tierTone(vitals.tier) === "ok" ? "ok" : "warn"}>{tierLabel(vitals.tier)}</Badge>
                  </div>
                </div>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={toggleSleep}
                      aria-label={vitals.state === "sleeping" ? "Wake Cletus" : "Put Cletus to sleep"}
                    >
                      {vitals.state === "sleeping" ? <Sun /> : <Moon />}
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>{vitals.state === "sleeping" ? "Wake" : "Sleep 30m"}</TooltipContent>
                </Tooltip>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={togglePaused}
                      aria-label={paused ? "Resume live feed" : "Pause live feed"}
                    >
                      {paused ? <Play /> : <Pause />}
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>{paused ? "Resume feed" : "Pause feed"}</TooltipContent>
                </Tooltip>
              </div>
            </header>

            <main className="flex-1 px-4 py-5 pb-40 md:px-6 md:pb-28">
              {view === "overview" && <OverviewView />}
              {view === "treasury" && <TreasuryView />}
              {view === "work" && <WorkView />}
              {view === "colony" && <ColonyView />}
              {view === "inbox" && <InboxView />}
              {view === "logs" && <LogsView />}
              {view === "policy" && <PolicyView />}
            </main>
          </div>
        </div>

        <div className="pointer-events-none fixed inset-x-0 bottom-0 z-40">
          <div className="pointer-events-auto mx-auto flex max-w-7xl flex-col gap-2 px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] md:pl-56">
            {view !== "inbox" ? <DecreeBar /> : null}
            <nav className="flex items-center justify-around rounded-2xl bg-card px-1 py-1 shadow-[var(--shadow-border)] md:hidden" aria-label="Mobile">
              {NAV.filter((n) => MOBILE_PRIMARY.includes(n.id)).map((item) => (
                <NavButton
                  key={item.id}
                  item={item}
                  active={view === item.id}
                  onSelect={setView}
                  compact
                  badge={item.id === "inbox" && inboxOpen > 0 ? inboxOpen : undefined}
                />
              ))}
              <Sheet open={moreOpen} onOpenChange={setMoreOpen}>
                <SheetTrigger asChild>
                  <button
                    type="button"
                    className={cn(
                      "flex min-h-11 min-w-11 flex-col items-center justify-center gap-0.5 rounded-md px-2 text-xs text-muted-foreground",
                      !MOBILE_PRIMARY.includes(view) && "text-foreground",
                    )}
                  >
                    <Menu className="size-4" />
                    More
                  </button>
                </SheetTrigger>
                <SheetContent side="bottom">
                  <SheetHeader>
                    <SheetTitle>More</SheetTitle>
                  </SheetHeader>
                  <div className="grid grid-cols-3 gap-2">
                    {NAV.filter((n) => !MOBILE_PRIMARY.includes(n.id)).map((item) => (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => {
                          setView(item.id);
                          setMoreOpen(false);
                        }}
                        className="flex min-h-11 flex-col items-center justify-center gap-1 rounded-md bg-secondary px-2 py-3 text-sm"
                      >
                        <item.icon className="size-4" />
                        {item.label}
                      </button>
                    ))}
                  </div>
                </SheetContent>
              </Sheet>
            </nav>
          </div>
        </div>

        <Toaster
          theme="dark"
          position="top-center"
          toastOptions={{
            className: "bg-card text-card-foreground border-border",
          }}
        />
      </div>
    </TooltipProvider>
  );
}

function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <div className={cn("flex items-center gap-2", compact && "gap-2")}>
      <span className="flex size-8 items-center justify-center rounded-md bg-primary text-sm text-primary-foreground font-display">
        C
      </span>
      {compact ? null : (
        <div>
          <p className="font-display text-base leading-tight font-medium">Cletus</p>
          <p className="text-xs text-muted-foreground">Mission Control</p>
        </div>
      )}
    </div>
  );
}

function NavButton({
  item,
  active,
  onSelect,
  compact = false,
  badge,
}: {
  item: (typeof NAV)[number];
  active: boolean;
  onSelect: (id: ViewId) => void;
  compact?: boolean;
  badge?: number;
}) {
  const Icon = item.icon;
  if (compact) {
    return (
      <button
        type="button"
        onClick={() => onSelect(item.id)}
        aria-current={active ? "page" : undefined}
        className={cn(
          "relative flex min-h-11 min-w-11 flex-col items-center justify-center gap-0.5 rounded-md px-2 text-xs transition-colors",
          active ? "text-foreground" : "text-muted-foreground",
        )}
      >
        <Icon className="size-4" />
        {item.label}
        {badge ? (
          <span className="absolute top-1 right-1 size-1.5 rounded-full bg-warn" aria-hidden />
        ) : null}
      </button>
    );
  }
  return (
    <button
      type="button"
      onClick={() => onSelect(item.id)}
      aria-current={active ? "page" : undefined}
      className={cn(
        "flex min-h-11 items-center gap-2 rounded-md px-3 text-sm transition-colors",
        active ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-accent hover:text-foreground",
      )}
    >
      <Icon className="size-4" />
      {item.label}
      {badge ? (
        <span className="ml-auto rounded-full bg-accent px-1.5 text-xs tabular-nums text-muted-foreground">
          {badge}
        </span>
      ) : null}
    </button>
  );
}
