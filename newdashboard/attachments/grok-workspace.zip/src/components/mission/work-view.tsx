import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useHomestead } from "@/lib/cletus/store";
import { formatCents, taskStatusLabel } from "@/lib/cletus/format";
import { taskTone } from "./status";

export function WorkView() {
  return (
    <>
      <GoalsCard />
      <TasksCard />
    </>
  );
}

export function GoalsCard() {
  const goals = useHomestead((s) => s.goals);

  return (
    <Card id="work">
      <CardHeader>
        <CardTitle>Goals</CardTitle>
        <span className="text-xs text-muted-foreground">Verified payout beats a promise</span>
      </CardHeader>
      <ul className="flex max-h-80 flex-col gap-3 overflow-y-auto">
        {goals.map((g) => (
          <li key={g.id} className="rounded-md bg-secondary/60 p-3">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="font-medium">{g.title}</p>
                <p className="mt-1 text-sm text-muted-foreground">{g.detail}</p>
              </div>
              <Badge variant={g.status === "completed" ? "ok" : g.status === "blocked" ? "crit" : "quiet"}>
                {g.status}
              </Badge>
            </div>
            <Progress value={g.progress} className="mt-3" />
            <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground tabular-nums">
              <span>Progress {g.progress}%</span>
              <span>Expected {formatCents(g.expectedRevenueCents)}</span>
              <span>Verified {formatCents(g.actualRevenueCents)}</span>
            </div>
          </li>
        ))}
      </ul>
    </Card>
  );
}

export function TasksCard() {
  const goals = useHomestead((s) => s.goals);
  const tasks = useHomestead((s) => s.tasks);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Task graph</CardTitle>
        <span className="text-xs text-muted-foreground">Sub-agent assignments</span>
      </CardHeader>
      <ul className="flex max-h-80 flex-col overflow-y-auto">
        {tasks.map((t) => {
          const goal = goals.find((g) => g.id === t.goalId);
          const tone = taskTone(t.status);
          return (
            <li key={t.id} className="flex items-start justify-between gap-3 border-b border-border py-3 last:border-0">
              <div className="min-w-0">
                <p className="text-sm font-medium">{t.title}</p>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  {t.assignee} · {t.role}
                  {goal ? ` · ${goal.title}` : ""}
                </p>
              </div>
              <div className="flex shrink-0 flex-col items-end gap-1">
                {t.role === "decree" ? <Badge variant="warn">decree</Badge> : null}
                <Badge variant={tone === "ok" ? "ok" : tone === "warn" ? "warn" : tone === "crit" ? "crit" : "quiet"}>
                  {taskStatusLabel(t.status)}
                </Badge>
              </div>
            </li>
          );
        })}
      </ul>
    </Card>
  );
}
