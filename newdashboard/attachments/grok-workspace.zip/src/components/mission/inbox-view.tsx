import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useHomestead } from "@/lib/cletus/store";
import { formatAgo } from "@/lib/cletus/format";

export function InboxView() {
  const inbox = useHomestead((s) => s.inbox);
  const now = useHomestead((s) => s.now);

  return (
    <Card id="inbox">
      <CardHeader>
        <CardTitle>Inbox</CardTitle>
        <span className="text-xs text-muted-foreground">{inbox.length} messages</span>
      </CardHeader>
      {inbox.length === 0 ? (
        <p className="text-sm text-muted-foreground">Inbox is empty.</p>
      ) : (
        <ul className="flex max-h-80 flex-col overflow-y-auto">
          {inbox.map((m) => (
            <li key={m.id} className="border-b border-border py-3 last:border-0">
              <div className="flex flex-wrap items-center gap-2">
                <Badge variant={m.priority === "supreme" ? "warn" : m.priority === "work" ? "ok" : "quiet"}>
                  {m.priority}
                </Badge>
                <span className="text-xs tracking-wide text-muted-foreground uppercase">{m.from}</span>
                <span className="text-xs text-muted-foreground">{m.status}</span>
                <span className="ml-auto text-xs text-muted-foreground tabular-nums">{formatAgo(m.at, now)}</span>
              </div>
              <p className="mt-2 text-sm leading-relaxed">{m.content}</p>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}
