import { useState } from "react";
import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useHomestead } from "@/lib/cletus/store";
import { formatAgo, formatCents, formatUptime, stateLabel, tierLabel } from "@/lib/cletus/format";
import type { Thought } from "@/lib/cletus/types";
import { StatusDot, agentTone, alertTone, childTone, peerTone, taskTone, tierTone } from "./status";
import { SpendBars } from "./spend-bars";

export function OverviewView() {
  const vitals = useHomestead((s) => s.vitals);
  const now = useHomestead((s) => s.now);
  const alerts = useHomestead((s) => s.alerts);
  const thoughts = useHomestead((s) => s.thoughts);
  const tasks = useHomestead((s) => s.tasks);
  const children = useHomestead((s) => s.children);
  const heartbeats = useHomestead((s) => s.heartbeats);
  const entelechy = useHomestead((s) => s.entelechy);
  const spend24h = useHomestead((s) => s.spend24h);
  const peers = useHomestead((s) => s.peers);
  const goals = useHomestead((s) => s.goals);
  const setView = useHomestead((s) => s.setView);
  const [open, setOpen] = useState<Thought | null>(null);
  const latest = thoughts[0];
  const running = tasks.filter((t) => t.status === "running" || t.status === "assigned");
  const bounty = goals.find((g) => g.id === "gol_bounty");

  return (
    <div className="flex flex-col gap-4">
      <Card className="p-5">
        <p className="text-xs tracking-wide text-muted-foreground uppercase">Mission</p>
        <p className="mt-1 font-display text-2xl leading-snug tracking-tight text-balance">{entelechy.mission}</p>
        <p className="mt-2 max-w-3xl text-sm text-muted-foreground">{entelechy.recommendation}</p>
        <div className="mt-4 flex flex-wrap gap-2">
          <Badge variant="quiet">{entelechy.riskPosture}</Badge>
          <Badge variant="quiet">confidence {entelechy.confidence.toFixed(2)}</Badge>
          {bounty ? <Badge variant="ok">bounty {bounty.progress}%</Badge> : null}
        </div>
      </Card>

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Vital
          label="State"
          value={stateLabel(vitals.state)}
          hint={`Uptime ${formatUptime(vitals.startedAt, now)}`}
          tone={agentTone(vitals.state)}
          pulse={vitals.state === "running"}
        />
        <Vital
          label="Survival"
          value={tierLabel(vitals.tier)}
          hint={`${formatCents(vitals.creditsCents)} compute`}
          tone={tierTone(vitals.tier)}
        />
        <Vital label="Model" value={vitals.model} hint={`${vitals.turns.toLocaleString()} turns`} />
        <Vital
          label="Active work"
          value={String(running.length)}
          hint={`${children.filter((c) => c.status === "healthy").length} healthy children`}
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Latest thought</CardTitle>
            {latest ? (
              <span className="text-xs text-muted-foreground tabular-nums">{formatAgo(latest.at, now)}</span>
            ) : null}
          </CardHeader>
          {latest ? (
            <button
              type="button"
              onClick={() => setOpen(latest)}
              className="w-full rounded-md bg-secondary/60 p-3 text-left transition-colors hover:bg-secondary"
            >
              <p className="text-sm leading-relaxed">{latest.thinking}</p>
              {latest.speech ? (
                <p className="mt-2 border-l-2 border-primary/40 pl-3 text-sm text-muted-foreground italic">
                  {latest.speech}
                </p>
              ) : null}
              <p className="mt-3 text-xs text-muted-foreground">Open full turn</p>
            </button>
          ) : (
            <p className="text-sm text-muted-foreground">No thoughts yet.</p>
          )}
          <ul className="mt-3 flex flex-col gap-1.5">
            {thoughts.slice(1, 4).map((t) => (
              <li key={t.id}>
                <button
                  type="button"
                  onClick={() => setOpen(t)}
                  className="w-full rounded-md px-2 py-1.5 text-left text-sm text-muted-foreground hover:bg-secondary hover:text-foreground"
                >
                  <span className="mr-2 text-xs tabular-nums">{formatAgo(t.at, now)}</span>
                  {t.thinking.slice(0, 92)}
                  {t.thinking.length > 92 ? "…" : ""}
                </button>
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Alerts</CardTitle>
            <span className="text-xs text-muted-foreground">{alerts.length} open</span>
          </CardHeader>
          <ul className="flex flex-col gap-2">
            {alerts.map((a) => (
              <li key={a.id} className="flex gap-3 rounded-md bg-secondary/60 px-3 py-2.5">
                <StatusDot tone={alertTone(a.severity)} className="mt-1.5" />
                <div className="min-w-0">
                  <p className="text-sm font-medium">{a.title}</p>
                  <p className="text-sm text-muted-foreground">{a.detail}</p>
                </div>
                <span className="ml-auto shrink-0 text-xs text-muted-foreground tabular-nums">
                  {formatAgo(a.at, now)}
                </span>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>On the table</CardTitle>
            <button
              type="button"
              onClick={() => setView("work")}
              className="text-xs text-muted-foreground hover:text-foreground"
            >
              Open work
            </button>
          </CardHeader>
          <ul className="flex flex-col gap-2">
            {running.map((t) => (
              <li key={t.id} className="flex items-start justify-between gap-3 rounded-md bg-secondary/60 px-3 py-2.5">
                <div className="min-w-0">
                  <p className="text-sm font-medium">{t.title}</p>
                  <p className="text-xs text-muted-foreground">
                    {t.assignee} · {t.role}
                  </p>
                </div>
                <Badge variant={taskTone(t.status) === "warn" ? "warn" : "quiet"}>{t.status}</Badge>
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Colony</CardTitle>
            <button
              type="button"
              onClick={() => setView("colony")}
              className="text-xs text-muted-foreground hover:text-foreground"
            >
              Open colony
            </button>
          </CardHeader>
          <ul className="flex flex-col gap-2">
            {children.map((c) => (
              <li key={c.id} className="flex items-center gap-3 rounded-md bg-secondary/60 px-3 py-2.5">
                <StatusDot tone={childTone(c.status)} pulse={c.status === "healthy"} />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium">{c.name}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    {c.role} · {c.task}
                  </p>
                </div>
                <span className="text-xs text-muted-foreground tabular-nums">
                  {c.latencyMs ? `${c.latencyMs}ms` : "—"}
                </span>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Spend, last 24 hours</CardTitle>
            <button
              type="button"
              onClick={() => setView("treasury")}
              className="text-xs text-muted-foreground hover:text-foreground"
            >
              Open treasury
            </button>
          </CardHeader>
          <SpendBars data={spend24h} />
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Heartbeats</CardTitle>
          </CardHeader>
          <ul className="flex flex-col gap-3">
            {heartbeats.map((h) => (
              <li key={h.name}>
                <div className="mb-1 flex items-baseline justify-between gap-2">
                  <span className="text-sm">{h.name}</span>
                  <span className="text-xs text-muted-foreground tabular-nums">
                    {h.cadence} · {formatAgo(now - h.lastAgoMs, now)}
                  </span>
                </div>
                <Progress value={h.ok ? 100 : 20} />
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Peers</CardTitle>
          <span className="text-xs text-muted-foreground">Moltbook / colony chatter</span>
        </CardHeader>
        <ul className="grid gap-2 sm:grid-cols-3">
          {peers.map((p) => (
            <li key={p.id} className="rounded-md bg-secondary/60 px-3 py-2.5">
              <div className="flex items-center gap-2">
                <StatusDot tone={peerTone(p.status)} pulse={p.status === "online"} />
                <p className="text-sm font-medium">{p.name}</p>
              </div>
              <p className="mt-1 font-mono text-xs text-muted-foreground">{p.handle}</p>
              <p className="mt-2 text-sm text-muted-foreground">{p.note}</p>
              <p className="mt-2 text-xs text-muted-foreground tabular-nums">{formatAgo(now - p.lastAgoMs, now)}</p>
            </li>
          ))}
        </ul>
      </Card>

      <Dialog open={Boolean(open)} onOpenChange={(v) => !v && setOpen(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Turn</DialogTitle>
            <DialogDescription>
              {open ? formatAgo(open.at, now) : ""}
              {open?.tools.length ? ` · ${open.tools.join(", ")}` : ""}
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="max-h-96">
            {open ? (
              <div className="space-y-4 pr-3 font-mono text-sm leading-relaxed">
                <div>
                  <p className="mb-1 text-xs tracking-wide text-muted-foreground uppercase">Thinking</p>
                  <p className="whitespace-pre-wrap font-sans text-foreground">{open.thinking}</p>
                </div>
                {open.speech ? (
                  <div>
                    <p className="mb-1 text-xs tracking-wide text-muted-foreground uppercase">Speech</p>
                    <p className="whitespace-pre-wrap font-sans">{open.speech}</p>
                  </div>
                ) : null}
              </div>
            ) : null}
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Vital({
  label,
  value,
  hint,
  tone,
  pulse,
}: {
  label: string;
  value: string;
  hint: string;
  tone?: "ok" | "warn" | "crit" | "mute";
  pulse?: boolean;
}) {
  return (
    <Card className="p-4">
      <p className="text-xs tracking-wide text-muted-foreground uppercase">{label}</p>
      <p className="mt-1 flex items-center gap-2 font-display text-2xl leading-tight tracking-tight">
        {tone ? <StatusDot tone={tone} pulse={pulse} /> : null}
        <span className="tabular-nums">{value}</span>
      </p>
      <p className="mt-1 text-xs text-muted-foreground">{hint}</p>
    </Card>
  );
}
