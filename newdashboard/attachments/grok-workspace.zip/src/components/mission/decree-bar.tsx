import { useState, type FormEvent } from "react";
import { Send } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useHomestead } from "@/lib/cletus/store";
import { cn } from "@/lib/utils";

export function DecreeBar({
  variant = "bar",
  inputId = "decree",
}: {
  variant?: "bar" | "card";
  inputId?: string;
}) {
  const issueDecree = useHomestead((s) => s.issueDecree);
  const pendingAck = useHomestead((s) => s.pendingAck);
  const [value, setValue] = useState("");

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const text = value.trim();
    if (!text) return;
    issueDecree(text);
    setValue("");
    toast("Decree queued", { description: "Cletus will drop background work and take this next." });
  }

  const form = (
    <form onSubmit={onSubmit} className={cn("flex items-center gap-2", variant === "bar" && "p-2 pl-3")}>
      <label htmlFor={inputId} className="sr-only">
        Creator decree
      </label>
      <Input
        id={inputId}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="Issue a supreme command — overrides every heartbeat and status ping"
        className="h-11 min-w-0 flex-1 border-0 bg-transparent shadow-none focus-visible:ring-0"
        autoComplete="off"
      />
      <Button type="submit" className="shrink-0" aria-label="Issue decree">
        <Send />
        <span className="hidden sm:inline">Issue decree</span>
      </Button>
    </form>
  );

  if (variant === "bar") {
    return <div className="rounded-2xl bg-card shadow-[var(--shadow-border)]">{form}</div>;
  }

  return (
    <section
      id="decree"
      className="rounded-2xl bg-card p-4 shadow-[var(--shadow-border)] ring-1 ring-primary/20"
    >
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="font-display text-lg font-medium tracking-tight">Creator decree</h2>
          <p className="text-sm text-muted-foreground">Supreme priority. Cannot be overwritten by a status ping.</p>
        </div>
        <Badge variant="warn">{pendingAck ? "claiming" : "ready"}</Badge>
      </div>
      <div className="rounded-xl bg-secondary/70">{form}</div>
    </section>
  );
}
