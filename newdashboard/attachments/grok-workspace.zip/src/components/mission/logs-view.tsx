import { useEffect, useMemo, useRef, useState } from "react";
import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useHomestead } from "@/lib/cletus/store";
import { formatClock, logLevelLabel } from "@/lib/cletus/format";
import type { LogLevel } from "@/lib/cletus/types";
import { cn } from "@/lib/utils";

const FILTERS: Array<{ id: "all" | LogLevel; label: string }> = [
  { id: "all", label: "All" },
  { id: "info", label: "Info" },
  { id: "warn", label: "Warn" },
  { id: "error", label: "Error" },
  { id: "tool", label: "Tool" },
  { id: "thought", label: "Mind" },
];

export function LogsView() {
  const logs = useHomestead((s) => s.logs);
  const now = useHomestead((s) => s.now);
  const [filter, setFilter] = useState<(typeof FILTERS)[number]["id"]>("all");
  const [auto, setAuto] = useState(true);
  const scroller = useRef<HTMLDivElement>(null);

  const visible = useMemo(
    () => (filter === "all" ? logs : logs.filter((l) => l.level === filter)),
    [logs, filter],
  );

  useEffect(() => {
    if (!auto) return;
    const el = scroller.current;
    if (el) el.scrollTop = 0;
  }, [visible, auto]);

  return (
    <Card id="logs">
      <CardHeader className="flex-col items-stretch gap-3 sm:flex-row sm:items-center">
        <CardTitle>Unified activity log</CardTitle>
        <div className="flex flex-wrap gap-1">
          {FILTERS.map((f) => (
            <Button
              key={f.id}
              type="button"
              size="sm"
              variant={filter === f.id ? "default" : "ghost"}
              onClick={() => setFilter(f.id)}
            >
              {f.label}
            </Button>
          ))}
          <Button type="button" size="sm" variant={auto ? "secondary" : "ghost"} onClick={() => setAuto((v) => !v)}>
            Autoscroll {auto ? "on" : "off"}
          </Button>
        </div>
      </CardHeader>
      <div
        ref={scroller}
        className="h-80 overflow-y-auto rounded-md bg-background p-3 font-mono text-xs leading-relaxed"
      >
        {visible.length === 0 ? (
          <p className="text-muted-foreground">No lines for this filter.</p>
        ) : (
          visible.map((line) => (
            <p key={line.id} className="flex flex-wrap gap-x-3 gap-y-0.5 py-0.5">
              <span className="text-muted-foreground tabular-nums">{formatClock(line.at)}</span>
              <span
                className={cn(
                  "w-12 shrink-0 uppercase",
                  line.level === "error" && "text-destructive",
                  line.level === "warn" && "text-warn",
                  line.level === "thought" && "text-ok",
                  line.level === "tool" && "text-foreground",
                  line.level === "info" && "text-muted-foreground",
                )}
              >
                {logLevelLabel(line.level)}
              </span>
              <span className="w-24 shrink-0 text-muted-foreground">{line.source}</span>
              <span className="min-w-0 flex-1 break-all text-foreground">{line.message}</span>
            </p>
          ))
        )}
        <p className="sr-only">Clock {now}</p>
      </div>
    </Card>
  );
}
