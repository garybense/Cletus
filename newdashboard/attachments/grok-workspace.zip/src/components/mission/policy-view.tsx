import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useHomestead } from "@/lib/cletus/store";
import { formatAgo } from "@/lib/cletus/format";

export function PolicyView() {
  return (
    <>
      <EntelechyCard />
      <SkillsCard />
    </>
  );
}

export function EntelechyCard() {
  const entelechy = useHomestead((s) => s.entelechy);

  return (
    <Card id="policy">
      <CardHeader>
        <CardTitle>Entelechy capsule</CardTitle>
        <Badge variant="quiet">guidance, not permission</Badge>
      </CardHeader>
      <p className="font-display text-xl leading-snug tracking-tight text-balance">{entelechy.mission}</p>
      <dl className="mt-4 grid gap-3 sm:grid-cols-3">
        <div>
          <dt className="text-xs tracking-wide text-muted-foreground uppercase">Risk posture</dt>
          <dd className="mt-1 font-mono text-sm">{entelechy.riskPosture}</dd>
        </div>
        <div>
          <dt className="text-xs tracking-wide text-muted-foreground uppercase">Confidence</dt>
          <dd className="mt-1 font-mono text-sm tabular-nums">{entelechy.confidence.toFixed(2)}</dd>
        </div>
        <div>
          <dt className="text-xs tracking-wide text-muted-foreground uppercase">Recommend</dt>
          <dd className="mt-1 text-sm">{entelechy.recommendation}</dd>
        </div>
      </dl>
      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <div>
          <p className="mb-2 text-xs tracking-wide text-muted-foreground uppercase">Priorities</p>
          <ul className="flex flex-col gap-1.5 text-sm">
            {entelechy.priorities.map((p) => (
              <li key={p} className="rounded-md bg-secondary/60 px-3 py-2">
                {p}
              </li>
            ))}
          </ul>
        </div>
        <div>
          <p className="mb-2 text-xs tracking-wide text-muted-foreground uppercase">Avoid</p>
          <ul className="flex flex-col gap-1.5 text-sm">
            {entelechy.avoid.map((p) => (
              <li key={p} className="rounded-md bg-secondary/60 px-3 py-2">
                {p}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Card>
  );
}

export function SkillsCard() {
  const skills = useHomestead((s) => s.skills);
  const denials = useHomestead((s) => s.denials);
  const now = useHomestead((s) => s.now);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Skills & denials</CardTitle>
      </CardHeader>
      <ul className="flex flex-col gap-2">
        {skills.map((s) => (
          <li key={s.name} className="flex items-start justify-between gap-3 rounded-md bg-secondary/60 px-3 py-2.5">
            <div>
              <p className="font-mono text-sm">{s.name}</p>
              <p className="mt-1 text-sm text-muted-foreground">{s.summary}</p>
            </div>
            <Badge variant={s.enabled ? "ok" : "quiet"}>{s.enabled ? "on" : "off"}</Badge>
          </li>
        ))}
      </ul>
      <p className="mt-4 mb-2 text-xs tracking-wide text-muted-foreground uppercase">First denial wins</p>
      <ul className="flex flex-col gap-2">
        {denials.map((d) => (
          <li key={d.id} className="rounded-md bg-secondary/60 px-3 py-2.5">
            <div className="flex items-center justify-between gap-2">
              <span className="font-mono text-sm">{d.tool}</span>
              <span className="text-xs text-muted-foreground tabular-nums">{formatAgo(d.at, now)}</span>
            </div>
            <p className="mt-1 text-sm text-muted-foreground">{d.rule}</p>
          </li>
        ))}
      </ul>
    </Card>
  );
}
