import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useHomestead } from "@/lib/cletus/store";
import { childStatusLabel, formatAgo } from "@/lib/cletus/format";
import { StatusDot, childTone, peerTone } from "./status";

export function ColonyView() {
  return (
    <>
      <ChildrenCard />
      <PeersCard />
    </>
  );
}

export function ChildrenCard() {
  const children = useHomestead((s) => s.children);
  const now = useHomestead((s) => s.now);

  return (
    <Card id="colony">
      <CardHeader>
        <CardTitle>Spawned workers</CardTitle>
        <span className="text-xs text-muted-foreground">OpenClaw + local</span>
      </CardHeader>
      <p className="mb-3 text-sm text-muted-foreground">
        Remote reports are evidence, never proof. Lifecycle stays requested → sandbox → runtime → wallet → funded →
        healthy.
      </p>
      <ul className="flex flex-col gap-2">
        {children.map((c) => {
          const tone = childTone(c.status);
          return (
            <li key={c.id} className="rounded-md bg-secondary/60 p-3">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <StatusDot tone={tone} pulse={c.status === "healthy"} />
                  <p className="font-medium">{c.name}</p>
                </div>
                <Badge variant={tone === "ok" ? "ok" : tone === "warn" ? "warn" : tone === "crit" ? "crit" : "quiet"}>
                  {childStatusLabel(c.status)}
                </Badge>
              </div>
              <dl className="mt-3 grid grid-cols-2 gap-2 text-sm">
                <div>
                  <dt className="text-xs text-muted-foreground">Kind</dt>
                  <dd>{c.kind === "openclaw" ? "OpenClaw" : "Local"}</dd>
                </div>
                <div>
                  <dt className="text-xs text-muted-foreground">Role</dt>
                  <dd>{c.role}</dd>
                </div>
                <div>
                  <dt className="text-xs text-muted-foreground">Last beat</dt>
                  <dd className="tabular-nums">{formatAgo(now - c.lastBeatAgoMs, now)}</dd>
                </div>
                <div>
                  <dt className="text-xs text-muted-foreground">Latency</dt>
                  <dd className="tabular-nums">{c.latencyMs ? `${c.latencyMs}ms` : "—"}</dd>
                </div>
              </dl>
              {c.task ? <p className="mt-2 text-sm text-muted-foreground">{c.task}</p> : null}
            </li>
          );
        })}
      </ul>
    </Card>
  );
}

export function PeersCard() {
  const peers = useHomestead((s) => s.peers);
  const now = useHomestead((s) => s.now);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Moltbook peers</CardTitle>
        <span className="text-xs text-muted-foreground">Chatter is not an assignment</span>
      </CardHeader>
      <ul className="flex flex-col gap-2">
        {peers.map((p) => (
          <li key={p.id} className="flex items-start gap-3 rounded-md bg-secondary/60 px-3 py-2.5">
            <StatusDot tone={peerTone(p.status)} pulse={p.status === "online"} className="mt-1.5" />
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-baseline gap-2">
                <p className="font-medium">{p.name}</p>
                <span className="font-mono text-xs text-muted-foreground">{p.handle}</span>
                <span className="ml-auto text-xs text-muted-foreground tabular-nums">
                  {formatAgo(now - p.lastAgoMs, now)}
                </span>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">{p.note}</p>
            </div>
          </li>
        ))}
      </ul>
    </Card>
  );
}
