import { lazy, Suspense, useEffect, useState } from "react";
import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useHomestead } from "@/lib/cletus/store";
import { formatAgo, formatCents, formatCredits } from "@/lib/cletus/format";
import { SpendBars } from "./spend-bars";

const SpendChart = lazy(() => import("./spend-chart"));

export function TreasuryView() {
  const vitals = useHomestead((s) => s.vitals);
  const spend24h = useHomestead((s) => s.spend24h);
  const spendByModel = useHomestead((s) => s.spendByModel);
  const denials = useHomestead((s) => s.denials);
  const now = useHomestead((s) => s.now);
  const spent24 = spend24h.reduce((sum, p) => sum + p.cents, 0);
  const reservePct = Math.min(100, Math.round((vitals.reserveCents / Math.max(vitals.creditsCents, 1)) * 100));
  const [chartReady, setChartReady] = useState(false);

  useEffect(() => {
    setChartReady(true);
  }, []);

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Compute credits" value={formatCredits(vitals.creditsCents)} hint="Live-confirmed, not cached" />
        <Stat label="USDC" value={formatCents(vitals.usdcCents)} hint="External balance" />
        <Stat label="Protected reserve" value={formatCents(vitals.reserveCents)} hint={`${reservePct}% of compute`} />
        <Stat label="Inference 24h" value={formatCents(spent24)} hint="From inference_costs" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Spend, last 24 hours</CardTitle>
          <span className="text-xs text-muted-foreground">Cents of compute, hourly</span>
        </CardHeader>
        <div className="h-56">
          {chartReady ? (
            <Suspense fallback={<SpendBars data={spend24h} heightClass="h-44" />}>
              <SpendChart data={spend24h} />
            </Suspense>
          ) : (
            <SpendBars data={spend24h} heightClass="h-44" />
          )}
        </div>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>By model</CardTitle>
          </CardHeader>
          <table className="w-full text-sm">
            <thead className="text-left text-xs tracking-wide text-muted-foreground uppercase">
              <tr>
                <th className="pb-2 font-medium">Model</th>
                <th className="pb-2 text-right font-medium">Calls</th>
                <th className="pb-2 text-right font-medium">Cost</th>
              </tr>
            </thead>
            <tbody>
              {spendByModel.map((m) => (
                <tr key={m.model} className="border-t border-border">
                  <td className="py-2.5 font-mono text-xs">{m.model}</td>
                  <td className="py-2.5 text-right tabular-nums">{m.calls}</td>
                  <td className="py-2.5 text-right tabular-nums">{formatCents(m.cents)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Guardrails</CardTitle>
          </CardHeader>
          <ul className="flex flex-col gap-2 text-sm">
            <Rule k="Max single transfer" v="$50.00" />
            <Rule k="Max hourly transfers" v="$100.00" />
            <Rule k="Max daily transfers" v="$250.00" />
            <Rule k="Minimum reserve" v="$10.00" />
            <Rule k="Max x402 payment" v="$1.00" />
            <Rule k="Max inference / day" v="$500.00" />
          </ul>
          <div className="mt-4">
            <p className="mb-2 text-xs tracking-wide text-muted-foreground uppercase">Recent denials</p>
            <ul className="flex flex-col gap-2">
              {denials.map((d) => (
                <li key={d.id} className="rounded-md bg-secondary/60 px-3 py-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-xs">{d.tool}</span>
                    <Badge variant="crit">denied</Badge>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">{d.rule}</p>
                  <p className="mt-1 text-xs text-muted-foreground tabular-nums">{formatAgo(d.at, now)}</p>
                </li>
              ))}
            </ul>
          </div>
        </Card>
      </div>
    </div>
  );
}

function Stat({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <Card className="p-4">
      <p className="text-xs tracking-wide text-muted-foreground uppercase">{label}</p>
      <p className="mt-1 font-display text-2xl leading-tight tracking-tight tabular-nums">{value}</p>
      <p className="mt-1 text-xs text-muted-foreground">{hint}</p>
    </Card>
  );
}

function Rule({ k, v }: { k: string; v: string }) {
  return (
    <li className="flex items-baseline justify-between gap-3 border-b border-border py-2 last:border-0">
      <span className="text-muted-foreground">{k}</span>
      <span className="font-mono text-xs tabular-nums">{v}</span>
    </li>
  );
}
