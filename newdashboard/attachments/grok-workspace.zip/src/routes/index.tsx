import { createFileRoute } from "@tanstack/react-router";
import { MissionApp } from "@/components/mission/app-shell";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <MissionApp />;
}
