//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cwkbrdhv.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CMjMRGph.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CMjMRGph.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes--Ksx0ogj.js"]
	}
} });
//#endregion
export { tsrStartManifest };
