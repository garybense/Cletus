import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as formatCents } from "./routes-Belax-jP.mjs";
import { a as CartesianGrid, i as Area, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/spend-chart-CDZn4El8.js
var import_jsx_runtime = require_jsx_runtime();
function SpendChart({ data }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
		width: "100%",
		height: "100%",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
			data,
			margin: {
				top: 8,
				right: 8,
				left: 0,
				bottom: 0
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
					stroke: "var(--color-border)",
					vertical: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
					dataKey: "hour",
					tick: {
						fill: "var(--color-muted-foreground)",
						fontSize: 11
					},
					axisLine: false,
					tickLine: false,
					interval: 3
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
					tick: {
						fill: "var(--color-muted-foreground)",
						fontSize: 11
					},
					axisLine: false,
					tickLine: false,
					width: 36
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
					contentStyle: {
						background: "var(--color-popover)",
						border: "1px solid var(--color-border)",
						borderRadius: 8,
						color: "var(--color-foreground)",
						fontSize: 12
					},
					formatter: (value) => [typeof value === "number" ? formatCents(value) : value, "Spend"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
					type: "monotone",
					dataKey: "cents",
					stroke: "var(--color-primary)",
					fill: "var(--color-primary)",
					fillOpacity: .12,
					strokeWidth: 1.5
				})
			]
		})
	});
}
//#endregion
export { SpendChart as default };
