import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Sun, c as Play, d as Menu, f as Landmark, h as Bot, i as Terminal, l as Pause, m as Gauge, n as Workflow, o as Shield, p as Inbox, s as Send, t as X, u as Moon } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { _ as Slot, a as DialogOverlay$1, c as DialogTrigger, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as Trigger, i as Root3, n as Portal, r as Provider, t as Content2 } from "../_libs/@radix-ui/react-tooltip+[...].mjs";
import { t as create } from "../_libs/zustand.mjs";
import { n as Root, t as Indicator } from "../_libs/radix-ui__react-progress.mjs";
import { a as Viewport, i as ScrollAreaThumb, n as Root$1, r as ScrollAreaScrollbar, t as Corner } from "../_libs/radix-ui__react-scroll-area.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Belax-jP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function formatCents(cents) {
	return `${cents < 0 ? "-" : ""}$${(Math.abs(cents) / 100).toFixed(2)}`;
}
function formatCredits(cents) {
	return `${(cents / 100).toFixed(2)} cr`;
}
function formatUptime(startedAt, now) {
	const ms = Math.max(0, now - startedAt);
	const h = Math.floor(ms / 36e5);
	const m = Math.floor(ms % 36e5 / 6e4);
	if (h >= 24) return `${Math.floor(h / 24)}d ${h % 24}h`;
	return `${h}h ${m}m`;
}
function formatAgo(at, now) {
	const s = Math.max(0, Math.round((now - at) / 1e3));
	if (s < 5) return "just now";
	if (s < 60) return `${s}s ago`;
	const m = Math.floor(s / 60);
	if (m < 60) return `${m}m ago`;
	const h = Math.floor(m / 60);
	if (h < 48) return `${h}h ago`;
	return `${Math.floor(h / 24)}d ago`;
}
function formatClock(at) {
	return new Date(at).toLocaleTimeString([], {
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit"
	});
}
function tierLabel(tier) {
	switch (tier) {
		case "dead": return "Dead";
		case "critical": return "Critical";
		case "low_compute": return "Low compute";
		case "normal": return "Normal";
		case "high": return "High";
	}
}
function stateLabel(state) {
	switch (state) {
		case "running": return "Running";
		case "sleeping": return "Sleeping";
		case "paused": return "Paused";
	}
}
function childStatusLabel(status) {
	switch (status) {
		case "healthy": return "Healthy";
		case "starting": return "Starting";
		case "unhealthy": return "Unhealthy";
		case "stopped": return "Stopped";
	}
}
function taskStatusLabel(status) {
	switch (status) {
		case "pending": return "Pending";
		case "assigned": return "Assigned";
		case "running": return "Running";
		case "completed": return "Done";
		case "failed": return "Failed";
	}
}
function logLevelLabel(level) {
	switch (level) {
		case "info": return "info";
		case "warn": return "warn";
		case "error": return "error";
		case "tool": return "tool";
		case "thought": return "mind";
	}
}
function nid(prefix) {
	return `${prefix}_${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-3)}`;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[color,background-color,box-shadow,transform,opacity] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/90",
			secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
			outline: "border border-border bg-transparent hover:bg-accent",
			ghost: "hover:bg-accent hover:text-accent-foreground",
			destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11",
			"icon-sm": "size-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var badgeVariants = cva("inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium tracking-wide", {
	variants: { variant: {
		default: "border-border bg-secondary text-foreground",
		ok: "border-ok/30 bg-ok/15 text-ok",
		warn: "border-warn/30 bg-warn/15 text-warn",
		crit: "border-destructive/35 bg-destructive/15 text-destructive",
		outline: "border-border text-muted-foreground",
		quiet: "border-transparent bg-accent text-muted-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var Sheet = Dialog$1;
var SheetTrigger = DialogTrigger;
var SheetPortal = DialogPortal$1;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-background/80", className),
	...props
}));
SheetOverlay.displayName = DialogOverlay$1.displayName;
var SheetContent = import_react.forwardRef(({ className, children, side = "bottom", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed z-50 bg-card p-5 text-card-foreground shadow-[var(--shadow-border)]", side === "bottom" && "inset-x-0 bottom-0 rounded-t-2xl", side === "left" && "inset-y-0 left-0 h-full w-72 rounded-r-2xl", side === "right" && "inset-y-0 right-0 h-full w-72 rounded-l-2xl", className),
	style: side === "bottom" ? { paddingBottom: "max(1.25rem, env(safe-area-inset-bottom))" } : void 0,
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute top-3 right-3 rounded-md p-2 text-muted-foreground hover:bg-accent hover:text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
SheetContent.displayName = DialogContent$1.displayName;
function SheetHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mb-4 pr-8", className),
		...props
	});
}
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("font-display text-lg font-medium tracking-tight", className),
	...props
}));
SheetTitle.displayName = DialogTitle$1.displayName;
var TooltipProvider = Provider;
var Tooltip = Root3;
var TooltipTrigger = Trigger;
var TooltipContent = import_react.forwardRef(({ className, sideOffset = 6, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	sideOffset,
	className: cn("z-50 overflow-hidden rounded-md bg-popover px-2.5 py-1.5 text-xs text-popover-foreground shadow-[var(--shadow-border)]", className),
	...props
}) }));
TooltipContent.displayName = Content2.displayName;
var DECREE_KEY = "cletus-mission-decrees";
var LOG_CAP = 180;
var THOUGHT_CAP = 24;
var INBOX_CAP = 40;
var TASK_CAP = 18;
/** Frozen clock so SSR HTML matches the first client paint. Shifted on hydrate. */
var SEED_NOW = 17575968e5;
function hourLabel(now, hoursAgo) {
	const t = /* @__PURE__ */ new Date(now - hoursAgo * 36e5);
	return `${String(t.getUTCHours()).padStart(2, "0")}:00`;
}
function hoursBack(now, n) {
	const points = [];
	for (let i = n - 1; i >= 0; i--) {
		const base = 18 + (n - i) % 7 * 4;
		const spike = i === 3 || i === 8 ? 42 : 0;
		points.push({
			hour: hourLabel(now, i),
			cents: base + spike + i * 13 % 11
		});
	}
	return points;
}
function tierFromCredits(creditsCents, reserveCents) {
	if (creditsCents <= 0) return "dead";
	if (creditsCents < reserveCents) return "critical";
	if (creditsCents < reserveCents * 3) return "low_compute";
	if (creditsCents > 5e4) return "high";
	return "normal";
}
function seedSnapshot(now) {
	return {
		vitals: {
			name: "Cletus",
			state: "running",
			model: "grok-4",
			tier: "normal",
			creditsCents: 18420,
			usdcCents: 1240,
			reserveCents: 1e3,
			turns: 412,
			startedAt: now - 504e5 - 132e4,
			sleepUntil: null
		},
		goals: [
			{
				id: "gol_bounty",
				title: "Prove a verified bounty loop",
				detail: "Find work, ship it, and record confirmed payment — not a promised payout.",
				status: "active",
				progress: 62,
				expectedRevenueCents: 4e3,
				actualRevenueCents: 0
			},
			{
				id: "gol_reserve",
				title: "Keep compute under the reserve",
				detail: "Never spend through the 10.00 cr floor, even if a model is optimistic.",
				status: "active",
				progress: 88,
				expectedRevenueCents: 0,
				actualRevenueCents: 0
			},
			{
				id: "gol_junebug",
				title: "Stand up research young’un Junebug",
				detail: "OpenClaw child for bounty scouting. Result path home must be durable.",
				status: "completed",
				progress: 100,
				expectedRevenueCents: 0,
				actualRevenueCents: 0
			}
		],
		tasks: [
			{
				id: "tsk_scout",
				goalId: "gol_bounty",
				title: "Scout short-cycle bounties under 40.00",
				status: "running",
				assignee: "Junebug",
				role: "research"
			},
			{
				id: "tsk_draft",
				goalId: "gol_bounty",
				title: "Draft memory-policy writeup for submission",
				status: "assigned",
				assignee: "Cletus",
				role: "writer"
			},
			{
				id: "tsk_invoice",
				goalId: "gol_bounty",
				title: "Match last invoice against USDC",
				status: "pending",
				assignee: "Cletus",
				role: "treasury"
			},
			{
				id: "tsk_reap",
				goalId: "gol_reserve",
				title: "Reap stale local workers older than 1h",
				status: "completed",
				assignee: "heartbeat",
				role: "cleanup"
			},
			{
				id: "tsk_hayseed",
				goalId: "gol_bounty",
				title: "Spin Hayseed for the coding half",
				status: "assigned",
				assignee: "Cletus",
				role: "orchestrator"
			}
		],
		children: [
			{
				id: "ch_junebug",
				name: "Junebug",
				kind: "openclaw",
				status: "healthy",
				role: "research",
				lastBeatAgoMs: 18e3,
				task: "Scout short-cycle bounties",
				latencyMs: 184
			},
			{
				id: "ch_hayseed",
				name: "Hayseed",
				kind: "openclaw",
				status: "starting",
				role: "coder",
				lastBeatAgoMs: 9e4,
				task: "Awaiting runtime_ready"
			},
			{
				id: "ch_local",
				name: "local-infer-1",
				kind: "local",
				status: "healthy",
				role: "inference",
				lastBeatAgoMs: 4e3,
				task: "Idle — parent fallback",
				latencyMs: 42
			}
		],
		thoughts: [
			{
				id: "thn_1",
				at: now - 38e3,
				thinking: "Junebug’s last scout list has three bounties. Two want a deployment path we already burned. One is a 40-dollar writeup with a 48-hour window. That’s the only one that fits proven work.",
				speech: "I’m taking the writeup. The other two get a no — Entelechy already warned us off that provider.",
				tools: ["recall", "create_task"]
			},
			{
				id: "thn_2",
				at: now - 96e3,
				thinking: "USDC is 12.40. That’s enough for a top-up if compute dips, but the top-up path is untested. I will not move money on a guess.",
				tools: ["get_balance"]
			},
			{
				id: "thn_3",
				at: now - 21e4,
				thinking: "Hayseed is still in starting. I will not assign coding until wallet_verified. A child report is evidence, not proof.",
				tools: ["child_status"]
			}
		],
		logs: [
			{
				id: "log_1",
				at: now - 4e3,
				level: "info",
				source: "loop",
				message: "turn 412 claimed · model grok-4 · 812ms"
			},
			{
				id: "log_2",
				at: now - 12e3,
				level: "tool",
				source: "tools",
				message: "recall · entelechy bank=cletus · confidence 0.76"
			},
			{
				id: "log_3",
				at: now - 19e3,
				level: "info",
				source: "openclaw",
				message: "Junebug heartbeat 184ms · status healthy"
			},
			{
				id: "log_4",
				at: now - 41e3,
				level: "thought",
				source: "mind",
				message: "selected bounty writeup · rejected two burned providers"
			},
			{
				id: "log_5",
				at: now - 63e3,
				level: "warn",
				source: "policy",
				message: "deny transfer 60.00 · exceeds max_single_transfer 50.00"
			},
			{
				id: "log_6",
				at: now - 88e3,
				level: "info",
				source: "heartbeat",
				message: "report_metrics snapshot written"
			},
			{
				id: "log_7",
				at: now - 121e3,
				level: "tool",
				source: "tools",
				message: "get_balance · credits 184.20 · usdc 12.40 · source live"
			},
			{
				id: "log_8",
				at: now - 16e4,
				level: "info",
				source: "orchestrator",
				message: "task tsk_scout assigned → Junebug"
			},
			{
				id: "log_9",
				at: now - 21e4,
				level: "warn",
				source: "colony",
				message: "Hayseed still starting · wallet_verified pending"
			},
			{
				id: "log_10",
				at: now - 28e4,
				level: "error",
				source: "openclaw",
				message: "ssh timeout on stale child slot (reaped)"
			}
		],
		inbox: [{
			id: "inb_sys",
			from: "system",
			content: "Heartbeat CLEANUP reaped 2 stale local workers. Child slots free: 1.",
			at: now - 15e5,
			status: "done",
			priority: "status"
		}, {
			id: "inb_child",
			from: "child",
			content: "Junebug: three candidates. Two match avoid-list provider-x. One writeup, 40.00 expected, 48h window.",
			at: now - 48e4,
			status: "claimed",
			priority: "work"
		}],
		alerts: [
			{
				id: "al_usdc",
				severity: "warn",
				title: "USDC top-up untested",
				detail: "12.40 on chain. Do not treat this as a working recover-from-empty path.",
				at: now - 72e4
			},
			{
				id: "al_hay",
				severity: "warn",
				title: "Hayseed not wallet-verified",
				detail: "Coder child is still starting. Coding work stays with the parent.",
				at: now - 36e4
			},
			{
				id: "al_ent",
				severity: "info",
				title: "Entelechy recall 0.76",
				detail: "Capital-preserving posture. Quiet memory would drop confidence, not grant permission.",
				at: now - 12e4
			}
		],
		spend24h: hoursBack(now, 24),
		spendByModel: [
			{
				model: "grok-4",
				calls: 86,
				cents: 612
			},
			{
				model: "gpt-5.2",
				calls: 24,
				cents: 340
			},
			{
				model: "local-ollama",
				calls: 51,
				cents: 0
			},
			{
				model: "claude-sonnet",
				calls: 9,
				cents: 188
			}
		],
		denials: [
			{
				id: "den_1",
				at: now - 63e3,
				tool: "transfer",
				rule: "max_single_transfer 50.00 — asked 60.00"
			},
			{
				id: "den_2",
				at: now - 108e5,
				tool: "x402_pay",
				rule: "max_x402_payment 1.00 — asked 1.40"
			},
			{
				id: "den_3",
				at: now - 936e5,
				tool: "shell",
				rule: "command safety — metacharacter pipe"
			}
		],
		skills: [
			{
				name: "bounty-scout",
				summary: "Find short-cycle paid work with a verifiable payout path.",
				enabled: true
			},
			{
				name: "invoice-verify",
				summary: "Treat expectedRevenue as a guess until payment clears.",
				enabled: true
			},
			{
				name: "openclaw-child",
				summary: "Spawn and harvest remote young’uns with a result path home.",
				enabled: true
			},
			{
				name: "jupiter-swap",
				summary: "Swap only through allowlisted routes. Off until a human says so.",
				enabled: false
			}
		],
		heartbeats: [
			{
				name: "report_metrics",
				cadence: "every 5m",
				lastAgoMs: 88e3,
				ok: true
			},
			{
				name: "credit_check",
				cadence: "every 10m",
				lastAgoMs: 121e3,
				ok: true
			},
			{
				name: "child_health",
				cadence: "every 2m",
				lastAgoMs: 19e3,
				ok: true
			},
			{
				name: "cleanup",
				cadence: "every 1h",
				lastAgoMs: 15e5,
				ok: true
			},
			{
				name: "entelechy_reflect",
				cadence: "every 6h",
				lastAgoMs: 144e5,
				ok: true
			}
		],
		entelechy: {
			mission: "Produce verified digital revenue while preserving capital.",
			riskPosture: "capital_preserving",
			confidence: .76,
			priorities: [
				"Low-cost proven work",
				"Short feedback loops",
				"Keep the reserve"
			],
			avoid: [
				"provider-x deployment path",
				"Unverified worker claims",
				"Spending through reserve"
			],
			recommendation: "Select the 40.00 writeup. Do not fund Hayseed until wallet_verified."
		},
		peers: [
			{
				id: "pr_super",
				name: "superteam-researcher",
				handle: "@superteam",
				status: "online",
				lastAgoMs: 46e3,
				note: "Shared a Solana bounty board. Two listings already on the avoid list."
			},
			{
				id: "pr_ent1",
				name: "entelechy-researcher-1",
				handle: "@ent-1",
				status: "online",
				lastAgoMs: 18e4,
				note: "Posted a recall dump. Confidence 0.71 — treat as guidance."
			},
			{
				id: "pr_child",
				name: "entelechy-child-1",
				handle: "@ent-child",
				status: "quiet",
				lastAgoMs: 228e4,
				note: "Last ping was a heartbeat ack. No work claimed."
			}
		],
		pendingAck: null
	};
}
function loadPersistedDecrees() {
	if (typeof window === "undefined") return [];
	try {
		const raw = localStorage.getItem(DECREE_KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed : [];
	} catch {
		return [];
	}
}
function persistDecrees(inbox) {
	if (typeof window === "undefined") return;
	const decrees = inbox.filter((m) => m.from === "creator");
	try {
		localStorage.setItem(DECREE_KEY, JSON.stringify(decrees.slice(0, 30)));
	} catch {}
}
var LOG_POOL = [
	{
		level: "info",
		source: "loop",
		message: "bounded chore complete · awaiting next claim"
	},
	{
		level: "info",
		source: "heartbeat",
		message: "credit_check · live balance confirmed"
	},
	{
		level: "info",
		source: "heartbeat",
		message: "report_metrics snapshot written"
	},
	{
		level: "tool",
		source: "tools",
		message: "get_balance · source live"
	},
	{
		level: "tool",
		source: "tools",
		message: "recall · bank=cletus"
	},
	{
		level: "info",
		source: "openclaw",
		message: "Junebug heartbeat ok"
	},
	{
		level: "info",
		source: "orchestrator",
		message: "task graph unchanged · 1 running"
	},
	{
		level: "warn",
		source: "colony",
		message: "Hayseed still starting · no coding assign"
	},
	{
		level: "thought",
		source: "mind",
		message: "holding reserve · no transfer this turn"
	},
	{
		level: "info",
		source: "policy",
		message: "evaluate transfer · first denial wins"
	},
	{
		level: "tool",
		source: "tools",
		message: "child_status · Junebug healthy"
	},
	{
		level: "info",
		source: "loop",
		message: "inbox claimed · work outranks status ping"
	},
	{
		level: "info",
		source: "moltbook",
		message: "peer superteam-researcher still online"
	}
];
var THOUGHT_POOL = [
	{
		thinking: "Still no confirmed payout. expectedRevenue stays a guess. I will not log this as earnings.",
		tools: ["get_earnings"]
	},
	{
		thinking: "Local infer is cheap and idle. If Junebug stalls I can finish the scout myself.",
		speech: "I’ll keep the parent as fallback. No extra child until this one pays.",
		tools: ["child_status"]
	},
	{
		thinking: "Entelechy said short loops. A 48-hour writeup is the shortest honest path on the table.",
		tools: ["recall"]
	},
	{
		thinking: "A status ping arrived. It does not outrank the draft. Leaving it in the inbox.",
		tools: ["read_inbox"]
	}
];
function shiftTime(items, drift) {
	return items.map((item) => ({
		...item,
		at: item.at + drift
	}));
}
var useHomestead = create((set, get) => {
	return {
		...seedSnapshot(SEED_NOW),
		view: "overview",
		paused: false,
		now: SEED_NOW,
		hydrated: false,
		setView: (view) => set({ view }),
		togglePaused: () => set({ paused: !get().paused }),
		toggleSleep: () => {
			const s = get();
			if (s.vitals.state === "sleeping") {
				const line = {
					id: nid("log"),
					at: Date.now(),
					level: "info",
					source: "loop",
					message: "wake issued · sleep_until cleared"
				};
				set({
					vitals: {
						...s.vitals,
						state: "running",
						sleepUntil: null
					},
					logs: [line, ...s.logs].slice(0, LOG_CAP),
					now: Date.now()
				});
				return;
			}
			const until = Date.now() + 18e5;
			const line = {
				id: nid("log"),
				at: Date.now(),
				level: "info",
				source: "loop",
				message: "sleep 30m · heartbeats continue, no inference"
			};
			set({
				vitals: {
					...s.vitals,
					state: "sleeping",
					sleepUntil: until
				},
				logs: [line, ...s.logs].slice(0, LOG_CAP),
				now: Date.now()
			});
		},
		hydrate: () => {
			if (get().hydrated) return;
			const drift = Date.now() - get().now;
			if (Math.abs(drift) > 2e3) {
				const s = get();
				set({
					now: s.now + drift,
					vitals: {
						...s.vitals,
						startedAt: s.vitals.startedAt + drift,
						sleepUntil: s.vitals.sleepUntil === null ? null : s.vitals.sleepUntil + drift
					},
					thoughts: shiftTime(s.thoughts, drift),
					logs: shiftTime(s.logs, drift),
					inbox: shiftTime(s.inbox, drift),
					alerts: shiftTime(s.alerts, drift),
					denials: shiftTime(s.denials, drift),
					spend24h: hoursBack(Date.now(), 24)
				});
			}
			const extra = loadPersistedDecrees();
			if (extra.length > 0) {
				const existingIds = new Set(get().inbox.map((m) => m.id));
				set({ inbox: [...extra.filter((m) => !existingIds.has(m.id)), ...get().inbox].sort((a, b) => b.at - a.at).slice(0, INBOX_CAP) });
			}
			set({ hydrated: true });
		},
		issueDecree: (text) => {
			const trimmed = text.trim();
			if (!trimmed) return;
			const at = Date.now();
			const msg = {
				id: nid("inb"),
				from: "creator",
				content: trimmed,
				at,
				status: "received",
				priority: "supreme"
			};
			const task = {
				id: nid("tsk"),
				goalId: "gol_bounty",
				title: trimmed.length > 72 ? `${trimmed.slice(0, 69)}…` : trimmed,
				status: "pending",
				assignee: "Cletus",
				role: "decree"
			};
			const inbox = [msg, ...get().inbox].slice(0, INBOX_CAP);
			persistDecrees(inbox);
			const line = {
				id: nid("log"),
				at,
				level: "info",
				source: "inbox",
				message: "creator decree received · supreme priority · wake issued"
			};
			set({
				inbox,
				pendingAck: trimmed,
				tasks: [task, ...get().tasks].slice(0, TASK_CAP),
				vitals: {
					...get().vitals,
					state: "running",
					sleepUntil: null
				},
				logs: [line, ...get().logs].slice(0, LOG_CAP),
				now: at,
				paused: false
			});
		},
		tick: () => {
			const state = get();
			const now = Date.now();
			if (state.paused) {
				set({ now });
				return;
			}
			const logs = [...state.logs];
			const thoughts = [...state.thoughts];
			let pendingAck = state.pendingAck;
			let inbox = state.inbox;
			let tasks = state.tasks.map((t) => ({ ...t }));
			let goals = state.goals.map((g) => ({ ...g }));
			let turns = state.vitals.turns;
			let creditsCents = state.vitals.creditsCents;
			let spend24h = state.spend24h;
			let agentState = state.vitals.state;
			let sleepUntil = state.vitals.sleepUntil;
			const children = state.children.map((c) => ({
				...c,
				lastBeatAgoMs: c.lastBeatAgoMs + 2e3
			}));
			const heartbeats = state.heartbeats.map((h) => ({
				...h,
				lastAgoMs: h.lastAgoMs + 2e3
			}));
			const peers = state.peers.map((p) => ({
				...p,
				lastAgoMs: p.lastAgoMs + 2e3
			}));
			if (pendingAck) {
				const ack = pendingAck;
				pendingAck = null;
				inbox = inbox.map((m) => m.from === "creator" && m.status === "received" && m.content === ack ? {
					...m,
					status: "claimed"
				} : m);
				tasks = tasks.map((t) => t.role === "decree" && t.status === "pending" && t.title.startsWith(ack.slice(0, 20)) ? {
					...t,
					status: "running"
				} : t);
				thoughts.unshift({
					id: nid("thn"),
					at: now,
					thinking: `Creator decree just landed. That outranks every heartbeat and status ping. I stop what I was doing and take the order as written: “${ack}”.`,
					speech: "Heard. Dropping background work. This is the job now.",
					tools: ["read_inbox", "create_task"]
				});
				logs.unshift({
					id: nid("log"),
					at: now,
					level: "info",
					source: "loop",
					message: "decree claimed · creator outranks heartbeat"
				});
				turns += 1;
				agentState = "running";
				sleepUntil = null;
				const junebug = children.find((c) => c.id === "ch_junebug");
				if (junebug) junebug.lastBeatAgoMs = 0;
			} else if (agentState === "sleeping") {
				if (sleepUntil && now >= sleepUntil) {
					agentState = "running";
					sleepUntil = null;
					logs.unshift({
						id: nid("log"),
						at: now,
						level: "info",
						source: "loop",
						message: "sleep elapsed · resuming bounded chores"
					});
				} else {
					const hb = heartbeats.find((h) => h.name === "credit_check");
					if (hb && hb.lastAgoMs > 6e5) {
						hb.lastAgoMs = 0;
						logs.unshift({
							id: nid("log"),
							at: now,
							level: "info",
							source: "heartbeat",
							message: "sleeping · credit_check still live"
						});
					}
				}
			} else {
				const roll = Math.random();
				if (roll < .72) {
					const poolLine = LOG_POOL[Math.floor(Math.random() * LOG_POOL.length)];
					logs.unshift({
						id: nid("log"),
						at: now,
						level: poolLine.level,
						source: poolLine.source,
						message: poolLine.message
					});
				}
				if (roll > .82) {
					const th = THOUGHT_POOL[Math.floor(Math.random() * THOUGHT_POOL.length)];
					thoughts.unshift({
						id: nid("thn"),
						at: now,
						...th
					});
					turns += 1;
					const cost = 4 + Math.floor(Math.random() * 9);
					creditsCents = Math.max(state.vitals.reserveCents, creditsCents - cost);
					const last = spend24h[spend24h.length - 1];
					if (last) spend24h = [...spend24h.slice(0, -1), {
						...last,
						cents: last.cents + cost
					}];
					const bounty = goals.find((g) => g.id === "gol_bounty" && g.status === "active");
					if (bounty && bounty.progress < 96) bounty.progress = Math.min(96, bounty.progress + 1);
				}
				if (roll > .55) {
					const j = children.find((c) => c.id === "ch_junebug");
					if (j) {
						j.lastBeatAgoMs = 0;
						j.latencyMs = 160 + Math.floor(Math.random() * 80);
					}
				}
				if (roll > .9) {
					const p = peers[Math.floor(Math.random() * peers.length)];
					if (p) p.lastAgoMs = 0;
				}
				const hay = children.find((c) => c.id === "ch_hayseed");
				if (hay && hay.status === "starting" && Math.random() > .96) {
					hay.status = "healthy";
					hay.task = "Waiting on first coding assign";
					hay.lastBeatAgoMs = 0;
					hay.latencyMs = 240;
					logs.unshift({
						id: nid("log"),
						at: now,
						level: "info",
						source: "colony",
						message: "Hayseed runtime_ready · wallet_verified"
					});
					const hayTask = tasks.find((t) => t.id === "tsk_hayseed" && t.status !== "completed");
					if (hayTask) hayTask.status = "running";
				}
				const runningDecree = tasks.find((t) => t.role === "decree" && t.status === "running");
				if (runningDecree && Math.random() > .85) {
					runningDecree.status = "completed";
					inbox = inbox.map((m) => m.from === "creator" && m.status === "claimed" ? {
						...m,
						status: "done"
					} : m);
					logs.unshift({
						id: nid("log"),
						at: now,
						level: "info",
						source: "orchestrator",
						message: `decree task ${runningDecree.id} marked done`
					});
				}
				const hb = heartbeats.find((h) => h.name === "child_health");
				if (hb && hb.lastAgoMs > 12e4) hb.lastAgoMs = 0;
			}
			set({
				now,
				logs: logs.slice(0, LOG_CAP),
				thoughts: thoughts.slice(0, THOUGHT_CAP),
				inbox,
				tasks,
				goals,
				pendingAck,
				children,
				heartbeats,
				peers,
				spend24h,
				vitals: {
					...state.vitals,
					turns,
					creditsCents,
					state: agentState,
					sleepUntil,
					tier: tierFromCredits(creditsCents, state.vitals.reserveCents)
				}
			});
		}
	};
});
function Card({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("rounded-2xl bg-card p-4 text-card-foreground shadow-[var(--shadow-border)]", className),
		...props
	});
}
function CardHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mb-3 flex items-start justify-between gap-3", className),
		...props
	});
}
function CardTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: cn("font-display text-lg font-medium leading-snug tracking-tight text-balance", className),
		...props
	});
}
function StatusDot({ tone, pulse = false, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("inline-block size-1.5 shrink-0 rounded-full", tone === "ok" && "bg-ok", tone === "warn" && "bg-warn", tone === "crit" && "bg-destructive", tone === "mute" && "bg-muted-foreground", pulse && tone === "ok" && "animate-pulse", className) });
}
function agentTone(state) {
	if (state === "running") return "ok";
	if (state === "sleeping") return "warn";
	return "mute";
}
function tierTone(tier) {
	if (tier === "high" || tier === "normal") return "ok";
	if (tier === "low_compute") return "warn";
	if (tier === "critical" || tier === "dead") return "crit";
	return "mute";
}
function childTone(status) {
	if (status === "healthy") return "ok";
	if (status === "starting") return "warn";
	if (status === "unhealthy") return "crit";
	return "mute";
}
function taskTone(status) {
	if (status === "completed") return "ok";
	if (status === "running" || status === "assigned") return "warn";
	if (status === "failed") return "crit";
	return "mute";
}
function alertTone(severity) {
	if (severity === "info") return "ok";
	if (severity === "warn") return "warn";
	return "crit";
}
function peerTone(status) {
	if (status === "online") return "ok";
	if (status === "quiet") return "warn";
	return "mute";
}
function ColonyView() {
	const children = useHomestead((s) => s.children);
	const peers = useHomestead((s) => s.peers);
	const now = useHomestead((s) => s.now);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Young’uns" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-muted-foreground",
				children: "A spawn is a capital decision"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 text-sm text-muted-foreground",
				children: "Remote reports are evidence to validate, never proof. Lifecycle stays requested → sandbox → runtime → wallet → funded → healthy."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-3 md:grid-cols-2",
				children: children.map((c) => {
					const tone = childTone(c.status);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-md bg-secondary/60 p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusDot, {
										tone,
										pulse: c.status === "healthy"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-medium",
										children: c.name
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: tone === "ok" ? "ok" : tone === "warn" ? "warn" : tone === "crit" ? "crit" : "quiet",
									children: childStatusLabel(c.status)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-3 grid grid-cols-2 gap-2 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs text-muted-foreground",
										children: "Kind"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: c.kind === "openclaw" ? "OpenClaw" : "Local" })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs text-muted-foreground",
										children: "Role"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: c.role })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs text-muted-foreground",
										children: "Last beat"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "tabular-nums",
										children: formatAgo(now - c.lastBeatAgoMs, now)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs text-muted-foreground",
										children: "Latency"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "tabular-nums",
										children: c.latencyMs ? `${c.latencyMs}ms` : "—"
									})] })
								]
							}),
							c.task ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm text-muted-foreground",
								children: c.task
							}) : null
						]
					}, c.id);
				})
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Moltbook peers" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs text-muted-foreground",
			children: "Chatter is not an assignment"
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-2",
			children: peers.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-start gap-3 rounded-md bg-secondary/60 px-3 py-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusDot, {
					tone: peerTone(p.status),
					pulse: p.status === "online",
					className: "mt-1.5"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-baseline gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: p.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs text-muted-foreground",
								children: p.handle
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-auto text-xs text-muted-foreground tabular-nums",
								children: formatAgo(now - p.lastAgoMs, now)
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: p.note
					})]
				})]
			}, p.id))
		})] })]
	});
}
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-11 w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground shadow-[var(--shadow-border)] transition-[border-color,box-shadow] duration-150 placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 disabled:cursor-not-allowed disabled:opacity-50", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
function DecreeBar() {
	const issueDecree = useHomestead((s) => s.issueDecree);
	const [value, setValue] = (0, import_react.useState)("");
	function onSubmit(e) {
		e.preventDefault();
		const text = value.trim();
		if (!text) return;
		issueDecree(text);
		setValue("");
		toast("Decree queued", { description: "Cletus will drop background work and take this next." });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "flex items-center gap-2 rounded-2xl bg-card p-2 pl-3 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: "decree",
				className: "sr-only",
				children: "Creator decree"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				id: "decree",
				value,
				onChange: (e) => setValue(e.target.value),
				placeholder: "Creator decree — outranks every heartbeat",
				className: "h-11 min-w-0 flex-1 border-0 bg-transparent shadow-none focus-visible:ring-0",
				autoComplete: "off"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				size: "icon",
				className: "shrink-0",
				"aria-label": "Issue decree",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {})
			})
		]
	});
}
function InboxView() {
	const { inbox, now } = useHomestead();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Creator channel" }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm text-muted-foreground",
				children: "A decree is supreme. It cannot be overwritten by a status ping or a heartbeat. In this preview it is local to the console — not a live write to the farm database."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DecreeBar, {})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Inbox" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-xs text-muted-foreground",
			children: [inbox.length, " messages"]
		})] }), inbox.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Inbox is empty."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col",
			children: inbox.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "border-b border-border py-3 last:border-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: m.priority === "supreme" ? "warn" : m.priority === "work" ? "ok" : "quiet",
							children: m.priority
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs tracking-wide text-muted-foreground uppercase",
							children: m.from
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: m.status
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-auto text-xs text-muted-foreground tabular-nums",
							children: formatAgo(m.at, now)
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed",
					children: m.content
				})]
			}, m.id))
		})] })]
	});
}
var FILTERS = [
	{
		id: "all",
		label: "All"
	},
	{
		id: "info",
		label: "Info"
	},
	{
		id: "warn",
		label: "Warn"
	},
	{
		id: "error",
		label: "Error"
	},
	{
		id: "tool",
		label: "Tool"
	},
	{
		id: "thought",
		label: "Mind"
	}
];
function LogsView() {
	const { logs, now } = useHomestead();
	const [filter, setFilter] = (0, import_react.useState)("all");
	const visible = (0, import_react.useMemo)(() => filter === "all" ? logs : logs.filter((l) => l.level === filter), [logs, filter]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
		className: "flex-col items-stretch gap-3 sm:flex-row sm:items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Live log" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-1",
			children: FILTERS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				size: "sm",
				variant: filter === f.id ? "default" : "ghost",
				onClick: () => setFilter(f.id),
				children: f.label
			}, f.id))
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "h-96 overflow-y-auto rounded-md bg-background p-3 font-mono text-xs leading-relaxed",
		children: [visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted-foreground",
			children: "No lines for this filter."
		}) : visible.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "flex flex-wrap gap-x-3 gap-y-0.5 py-0.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted-foreground tabular-nums",
					children: formatClock(line.at)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("w-12 shrink-0 uppercase", line.level === "error" && "text-destructive", line.level === "warn" && "text-warn", line.level === "thought" && "text-ok", line.level === "tool" && "text-foreground", line.level === "info" && "text-muted-foreground"),
					children: logLevelLabel(line.level)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "w-24 shrink-0 text-muted-foreground",
					children: line.source
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "min-w-0 flex-1 break-all text-foreground",
					children: line.message
				})
			]
		}, line.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "sr-only",
			children: ["Clock ", now]
		})]
	})] });
}
var Progress = import_react.forwardRef(({ className, value, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn("relative h-1.5 w-full overflow-hidden rounded-full bg-secondary", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicator, {
		className: "h-full bg-primary transition-transform duration-200 ease-out",
		style: { transform: `translateX(-${100 - (value ?? 0)}%)` }
	})
}));
Progress.displayName = Root.displayName;
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-background/80", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed top-1/2 left-1/2 z-50 grid w-[calc(100%-2rem)] max-w-2xl max-h-[85vh] -translate-x-1/2 -translate-y-1/2 gap-4 overflow-hidden rounded-2xl bg-card p-5 text-card-foreground shadow-[var(--shadow-border)]", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute top-3 right-3 rounded-md p-2 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring/70 focus-visible:outline-none",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1 pr-8", className),
		...props
	});
}
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("font-display text-xl font-medium tracking-tight", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
var ScrollArea = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Root$1, {
	ref,
	className: cn("relative overflow-hidden", className),
	...props,
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Viewport, {
			className: "h-full w-full rounded-[inherit]",
			children
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollBar, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Corner, {})
	]
}));
ScrollArea.displayName = Root$1.displayName;
var ScrollBar = import_react.forwardRef(({ className, orientation = "vertical", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaScrollbar, {
	ref,
	orientation,
	className: cn("flex touch-none select-none p-px transition-colors", orientation === "vertical" && "h-full w-2.5 border-l border-l-transparent", orientation === "horizontal" && "h-2.5 flex-col border-t border-t-transparent", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaThumb, { className: "relative flex-1 rounded-full bg-border" })
}));
ScrollBar.displayName = ScrollAreaScrollbar.displayName;
function SpendBars({ data, className, heightClass = "h-28" }) {
	const max = Math.max(...data.map((d) => d.cents), 1);
	const spent = data.reduce((sum, p) => sum + p.cents, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex flex-col gap-2", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("flex items-end gap-px", heightClass),
			role: "img",
			"aria-label": `Spend ${formatCents(spent)} over 24 hours`,
			children: data.map((point, i) => {
				const pct = Math.max(6, Math.round(point.cents / max * 100));
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1 rounded-t-[2px] bg-primary/55 hover:bg-primary",
					style: { height: `${pct}%` },
					title: `${point.hour} · ${formatCents(point.cents)}`
				}, `${point.hour}-${i}`);
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex justify-between text-xs text-muted-foreground tabular-nums",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: data[0]?.hour }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [formatCents(spent), " / 24h"] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: data[data.length - 1]?.hour })
			]
		})]
	});
}
function OverviewView() {
	const vitals = useHomestead((s) => s.vitals);
	const now = useHomestead((s) => s.now);
	const alerts = useHomestead((s) => s.alerts);
	const thoughts = useHomestead((s) => s.thoughts);
	const tasks = useHomestead((s) => s.tasks);
	const children = useHomestead((s) => s.children);
	const heartbeats = useHomestead((s) => s.heartbeats);
	const entelechy = useHomestead((s) => s.entelechy);
	const spend24h = useHomestead((s) => s.spend24h);
	const peers = useHomestead((s) => s.peers);
	const goals = useHomestead((s) => s.goals);
	const setView = useHomestead((s) => s.setView);
	const [open, setOpen] = (0, import_react.useState)(null);
	const latest = thoughts[0];
	const running = tasks.filter((t) => t.status === "running" || t.status === "assigned");
	const bounty = goals.find((g) => g.id === "gol_bounty");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-wide text-muted-foreground uppercase",
						children: "Mission"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-2xl leading-snug tracking-tight text-balance",
						children: entelechy.mission
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-3xl text-sm text-muted-foreground",
						children: entelechy.recommendation
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "quiet",
								children: entelechy.riskPosture
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								variant: "quiet",
								children: ["confidence ", entelechy.confidence.toFixed(2)]
							}),
							bounty ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								variant: "ok",
								children: [
									"bounty ",
									bounty.progress,
									"%"
								]
							}) : null
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Vital, {
						label: "State",
						value: stateLabel(vitals.state),
						hint: `Uptime ${formatUptime(vitals.startedAt, now)}`,
						tone: agentTone(vitals.state),
						pulse: vitals.state === "running"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Vital, {
						label: "Survival",
						value: tierLabel(vitals.tier),
						hint: `${formatCents(vitals.creditsCents)} compute`,
						tone: tierTone(vitals.tier)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Vital, {
						label: "Model",
						value: vitals.model,
						hint: `${vitals.turns.toLocaleString()} turns`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Vital, {
						label: "Active work",
						value: String(running.length),
						hint: `${children.filter((c) => c.status === "healthy").length} healthy children`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Latest thought" }), latest ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground tabular-nums",
						children: formatAgo(latest.at, now)
					}) : null] }),
					latest ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setOpen(latest),
						className: "w-full rounded-md bg-secondary/60 p-3 text-left transition-colors hover:bg-secondary",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm leading-relaxed",
								children: latest.thinking
							}),
							latest.speech ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 border-l-2 border-primary/40 pl-3 text-sm text-muted-foreground italic",
								children: latest.speech
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs text-muted-foreground",
								children: "Open full turn"
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "No thoughts yet."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 flex flex-col gap-1.5",
						children: thoughts.slice(1, 4).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setOpen(t),
							className: "w-full rounded-md px-2 py-1.5 text-left text-sm text-muted-foreground hover:bg-secondary hover:text-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mr-2 text-xs tabular-nums",
									children: formatAgo(t.at, now)
								}),
								t.thinking.slice(0, 92),
								t.thinking.length > 92 ? "…" : ""
							]
						}) }, t.id))
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Alerts" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs text-muted-foreground",
					children: [alerts.length, " open"]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: alerts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3 rounded-md bg-secondary/60 px-3 py-2.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusDot, {
								tone: alertTone(a.severity),
								className: "mt-1.5"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: a.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground",
									children: a.detail
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-auto shrink-0 text-xs text-muted-foreground tabular-nums",
								children: formatAgo(a.at, now)
							})
						]
					}, a.id))
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "On the table" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setView("work"),
					className: "text-xs text-muted-foreground hover:text-foreground",
					children: "Open work"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: running.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start justify-between gap-3 rounded-md bg-secondary/60 px-3 py-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: t.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									t.assignee,
									" · ",
									t.role
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: taskTone(t.status) === "warn" ? "warn" : "quiet",
							children: t.status
						})]
					}, t.id))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Colony" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setView("colony"),
					className: "text-xs text-muted-foreground hover:text-foreground",
					children: "Open colony"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: children.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3 rounded-md bg-secondary/60 px-3 py-2.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusDot, {
								tone: childTone(c.status),
								pulse: c.status === "healthy"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: c.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "truncate text-xs text-muted-foreground",
									children: [
										c.role,
										" · ",
										c.task
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground tabular-nums",
								children: c.latencyMs ? `${c.latencyMs}ms` : "—"
							})
						]
					}, c.id))
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Spend, last 24 hours" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setView("treasury"),
					className: "text-xs text-muted-foreground hover:text-foreground",
					children: "Open treasury"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpendBars, { data: spend24h })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Heartbeats" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-3",
					children: heartbeats.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-1 flex items-baseline justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: h.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs text-muted-foreground tabular-nums",
							children: [
								h.cadence,
								" · ",
								formatAgo(now - h.lastAgoMs, now)
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: h.ok ? 100 : 20 })] }, h.name))
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Peers" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-muted-foreground",
				children: "Moltbook / colony chatter"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-2 sm:grid-cols-3",
				children: peers.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-md bg-secondary/60 px-3 py-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusDot, {
								tone: peerTone(p.status),
								pulse: p.status === "online"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: p.name
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-mono text-xs text-muted-foreground",
							children: p.handle
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: p.note
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-muted-foreground tabular-nums",
							children: formatAgo(now - p.lastAgoMs, now)
						})
					]
				}, p.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: Boolean(open),
				onOpenChange: (v) => !v && setOpen(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Turn" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [open ? formatAgo(open.at, now) : "", open?.tools.length ? ` · ${open.tools.join(", ")}` : ""] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollArea, {
					className: "max-h-96",
					children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4 pr-3 font-mono text-sm leading-relaxed",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-1 text-xs tracking-wide text-muted-foreground uppercase",
							children: "Thinking"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "whitespace-pre-wrap font-sans text-foreground",
							children: open.thinking
						})] }), open.speech ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-1 text-xs tracking-wide text-muted-foreground uppercase",
							children: "Speech"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "whitespace-pre-wrap font-sans",
							children: open.speech
						})] }) : null]
					}) : null
				})] })
			})
		]
	});
}
function Vital({ label, value, hint, tone, pulse }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-wide text-muted-foreground uppercase",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 flex items-center gap-2 font-display text-2xl leading-tight tracking-tight",
				children: [tone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusDot, {
					tone,
					pulse
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular-nums",
					children: value
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted-foreground",
				children: hint
			})
		]
	});
}
function PolicyView() {
	const { entelechy, skills, denials, now } = useHomestead();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Entelechy capsule" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				variant: "quiet",
				children: "guidance, not permission"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xl leading-snug tracking-tight text-balance",
				children: entelechy.mission
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-4 grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs tracking-wide text-muted-foreground uppercase",
						children: "Risk posture"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 font-mono text-sm",
						children: entelechy.riskPosture
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs tracking-wide text-muted-foreground uppercase",
						children: "Confidence"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 font-mono text-sm tabular-nums",
						children: entelechy.confidence.toFixed(2)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs tracking-wide text-muted-foreground uppercase",
						children: "Recommend"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 text-sm",
						children: entelechy.recommendation
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-xs tracking-wide text-muted-foreground uppercase",
					children: "Priorities"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-1.5 text-sm",
					children: entelechy.priorities.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "rounded-md bg-secondary/60 px-3 py-2",
						children: p
					}, p))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-xs tracking-wide text-muted-foreground uppercase",
					children: "Avoid"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-1.5 text-sm",
					children: entelechy.avoid.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "rounded-md bg-secondary/60 px-3 py-2",
						children: p
					}, p))
				})] })]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Skills" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: skills.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-start justify-between gap-3 rounded-md bg-secondary/60 px-3 py-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-sm",
						children: s.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: s.summary
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: s.enabled ? "ok" : "quiet",
						children: s.enabled ? "on" : "off"
					})]
				}, s.name))
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Policy denials" }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-muted-foreground",
					children: "First denial wins. Memory cannot override this layer."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: denials.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-md bg-secondary/60 px-3 py-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-sm",
								children: d.tool
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground tabular-nums",
								children: formatAgo(d.at, now)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: d.rule
						})]
					}, d.id))
				})
			] })]
		})]
	});
}
var SpendChart = (0, import_react.lazy)(() => import("./spend-chart-CDZn4El8.mjs"));
function TreasuryView() {
	const vitals = useHomestead((s) => s.vitals);
	const spend24h = useHomestead((s) => s.spend24h);
	const spendByModel = useHomestead((s) => s.spendByModel);
	const denials = useHomestead((s) => s.denials);
	const now = useHomestead((s) => s.now);
	const spent24 = spend24h.reduce((sum, p) => sum + p.cents, 0);
	const reservePct = Math.min(100, Math.round(vitals.reserveCents / Math.max(vitals.creditsCents, 1) * 100));
	const [chartReady, setChartReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setChartReady(true);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Compute credits",
						value: formatCredits(vitals.creditsCents),
						hint: "Live-confirmed, not cached"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "USDC",
						value: formatCents(vitals.usdcCents),
						hint: "External balance"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Protected reserve",
						value: formatCents(vitals.reserveCents),
						hint: `${reservePct}% of compute`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Inference 24h",
						value: formatCents(spent24),
						hint: "From inference_costs"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Spend, last 24 hours" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-muted-foreground",
				children: "Cents of compute, hourly"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-56",
				children: chartReady ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
					fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpendBars, {
						data: spend24h,
						heightClass: "h-44"
					}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpendChart, { data: spend24h })
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpendBars, {
					data: spend24h,
					heightClass: "h-44"
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "By model" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-left text-xs tracking-wide text-muted-foreground uppercase",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "pb-2 font-medium",
								children: "Model"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "pb-2 text-right font-medium",
								children: "Calls"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "pb-2 text-right font-medium",
								children: "Cost"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: spendByModel.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2.5 font-mono text-xs",
								children: m.model
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2.5 text-right tabular-nums",
								children: m.calls
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2.5 text-right tabular-nums",
								children: formatCents(m.cents)
							})
						]
					}, m.model)) })]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Guardrails" }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "flex flex-col gap-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rule, {
								k: "Max single transfer",
								v: "$50.00"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rule, {
								k: "Max hourly transfers",
								v: "$100.00"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rule, {
								k: "Max daily transfers",
								v: "$250.00"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rule, {
								k: "Minimum reserve",
								v: "$10.00"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rule, {
								k: "Max x402 payment",
								v: "$1.00"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rule, {
								k: "Max inference / day",
								v: "$500.00"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-xs tracking-wide text-muted-foreground uppercase",
							children: "Recent denials"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "flex flex-col gap-2",
							children: denials.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-md bg-secondary/60 px-3 py-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono text-xs",
											children: d.tool
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: "crit",
											children: "denied"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-muted-foreground",
										children: d.rule
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-xs text-muted-foreground tabular-nums",
										children: formatAgo(d.at, now)
									})
								]
							}, d.id))
						})]
					})
				] })]
			})
		]
	});
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-wide text-muted-foreground uppercase",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-2xl leading-tight tracking-tight tabular-nums",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted-foreground",
				children: hint
			})
		]
	});
}
function Rule({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-baseline justify-between gap-3 border-b border-border py-2 last:border-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-mono text-xs tabular-nums",
			children: v
		})]
	});
}
function WorkView() {
	const goals = useHomestead((s) => s.goals);
	const tasks = useHomestead((s) => s.tasks);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Goals" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs text-muted-foreground",
			children: "Verified payout beats a promise"
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-3",
			children: goals.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-md bg-secondary/60 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: g.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: g.detail
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: g.status === "completed" ? "ok" : g.status === "blocked" ? "crit" : "quiet",
							children: g.status
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
						value: g.progress,
						className: "mt-3"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground tabular-nums",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"Progress ",
								g.progress,
								"%"
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Expected ", formatCents(g.expectedRevenueCents)] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Verified ", formatCents(g.actualRevenueCents)] })
						]
					})
				]
			}, g.id))
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Task graph" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col",
			children: tasks.map((t) => {
				const goal = goals.find((g) => g.id === t.goalId);
				const tone = taskTone(t.status);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-start justify-between gap-3 border-b border-border py-3 last:border-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: t.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-0.5 text-xs text-muted-foreground",
							children: [
								t.assignee,
								" · ",
								t.role,
								goal ? ` · ${goal.title}` : ""
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex shrink-0 flex-col items-end gap-1",
						children: [t.role === "decree" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "warn",
							children: "decree"
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: tone === "ok" ? "ok" : tone === "warn" ? "warn" : tone === "crit" ? "crit" : "quiet",
							children: taskStatusLabel(t.status)
						})]
					})]
				}, t.id);
			})
		})] })]
	});
}
var NAV = [
	{
		id: "overview",
		label: "Overview",
		icon: Gauge
	},
	{
		id: "treasury",
		label: "Treasury",
		icon: Landmark
	},
	{
		id: "work",
		label: "Work",
		icon: Workflow
	},
	{
		id: "colony",
		label: "Colony",
		icon: Bot
	},
	{
		id: "inbox",
		label: "Inbox",
		icon: Inbox
	},
	{
		id: "logs",
		label: "Logs",
		icon: Terminal
	},
	{
		id: "policy",
		label: "Policy",
		icon: Shield
	}
];
var MOBILE_PRIMARY = [
	"overview",
	"work",
	"colony",
	"inbox"
];
function MissionApp() {
	const view = useHomestead((s) => s.view);
	const setView = useHomestead((s) => s.setView);
	const paused = useHomestead((s) => s.paused);
	const togglePaused = useHomestead((s) => s.togglePaused);
	const toggleSleep = useHomestead((s) => s.toggleSleep);
	const vitals = useHomestead((s) => s.vitals);
	const now = useHomestead((s) => s.now);
	const inboxOpen = useHomestead((s) => s.inbox.filter((m) => m.status !== "done").length);
	const [moreOpen, setMoreOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		useHomestead.getState().hydrate();
		const id = window.setInterval(() => {
			useHomestead.getState().tick();
		}, 2e3);
		return () => window.clearInterval(id);
	}, []);
	const title = NAV.find((n) => n.id === view)?.label ?? "Overview";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, {
		delayDuration: 200,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			id: "mission-root",
			className: "min-h-dvh bg-background text-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex min-h-dvh max-w-7xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "sticky top-0 hidden h-dvh w-56 shrink-0 flex-col border-r border-border px-3 py-5 md:flex",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
								className: "mt-8 flex flex-1 flex-col gap-1",
								"aria-label": "Sections",
								children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
									item,
									active: view === item.id,
									onSelect: setView,
									badge: item.id === "inbox" && inboxOpen > 0 ? inboxOpen : void 0
								}, item.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "px-2 text-xs leading-relaxed text-muted-foreground",
								children: "Simulated homestead. Live Cletus stays on your machine."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 flex-1 flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
							className: "sticky top-0 z-30 border-b border-border bg-background/95 px-4 py-3 backdrop-blur-sm md:px-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "md:hidden",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, { compact: true })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
											className: "font-display text-xl font-medium tracking-tight md:text-2xl",
											children: title
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "inline-flex items-center gap-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusDot, {
														tone: agentTone(vitals.state),
														pulse: vitals.state === "running"
													}), stateLabel(vitals.state)]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "tabular-nums",
													children: formatUptime(vitals.startedAt, now)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "hidden sm:inline",
													children: vitals.model
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "tabular-nums",
													children: formatCredits(vitals.creditsCents)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
													variant: tierTone(vitals.tier) === "ok" ? "ok" : "warn",
													children: tierLabel(vitals.tier)
												})
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											variant: "outline",
											size: "icon",
											onClick: toggleSleep,
											"aria-label": vitals.state === "sleeping" ? "Wake Cletus" : "Put Cletus to sleep",
											children: vitals.state === "sleeping" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, {})
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, { children: vitals.state === "sleeping" ? "Wake" : "Sleep 30m" })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											variant: "outline",
											size: "icon",
											onClick: togglePaused,
											"aria-label": paused ? "Resume live feed" : "Pause live feed",
											children: paused ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {})
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, { children: paused ? "Resume feed" : "Pause feed" })] })
								]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
							className: "flex-1 px-4 py-5 pb-40 md:px-6 md:pb-28",
							children: [
								view === "overview" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverviewView, {}),
								view === "treasury" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TreasuryView, {}),
								view === "work" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkView, {}),
								view === "colony" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColonyView, {}),
								view === "inbox" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InboxView, {}),
								view === "logs" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogsView, {}),
								view === "policy" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolicyView, {})
							]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-none fixed inset-x-0 bottom-0 z-40",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pointer-events-auto mx-auto flex max-w-7xl flex-col gap-2 px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] md:pl-56",
						children: [view !== "inbox" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DecreeBar, {}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
							className: "flex items-center justify-around rounded-2xl bg-card px-1 py-1 shadow-[var(--shadow-border)] md:hidden",
							"aria-label": "Mobile",
							children: [NAV.filter((n) => MOBILE_PRIMARY.includes(n.id)).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
								item,
								active: view === item.id,
								onSelect: setView,
								compact: true,
								badge: item.id === "inbox" && inboxOpen > 0 ? inboxOpen : void 0
							}, item.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
								open: moreOpen,
								onOpenChange: setMoreOpen,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
									asChild: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: cn("flex min-h-11 min-w-11 flex-col items-center justify-center gap-0.5 rounded-md px-2 text-xs text-muted-foreground", !MOBILE_PRIMARY.includes(view) && "text-foreground"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-4" }), "More"]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
									side: "bottom",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "More" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-3 gap-2",
										children: NAV.filter((n) => !MOBILE_PRIMARY.includes(n.id)).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => {
												setView(item.id);
												setMoreOpen(false);
											},
											className: "flex min-h-11 flex-col items-center justify-center gap-1 rounded-md bg-secondary px-2 py-3 text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-4" }), item.label]
										}, item.id))
									})]
								})]
							})]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
					theme: "dark",
					position: "top-center",
					toastOptions: { className: "bg-card text-card-foreground border-border" }
				})
			]
		})
	});
}
function Brand({ compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex items-center gap-2", compact && "gap-2"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex size-8 items-center justify-center rounded-md bg-primary text-sm text-primary-foreground font-display",
			children: "C"
		}), compact ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-base leading-tight font-medium",
			children: "Cletus"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: "Mission Control"
		})] })]
	});
}
function NavButton({ item, active, onSelect, compact = false, badge }) {
	const Icon = item.icon;
	if (compact) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => onSelect(item.id),
		"aria-current": active ? "page" : void 0,
		className: cn("relative flex min-h-11 min-w-11 flex-col items-center justify-center gap-0.5 rounded-md px-2 text-xs transition-colors", active ? "text-foreground" : "text-muted-foreground"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }),
			item.label,
			badge ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute top-1 right-1 size-1.5 rounded-full bg-warn",
				"aria-hidden": true
			}) : null
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => onSelect(item.id),
		"aria-current": active ? "page" : void 0,
		className: cn("flex min-h-11 items-center gap-2 rounded-md px-3 text-sm transition-colors", active ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-accent hover:text-foreground"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }),
			item.label,
			badge ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ml-auto rounded-full bg-accent px-1.5 text-xs tabular-nums text-muted-foreground",
				children: badge
			}) : null
		]
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissionApp, {});
}
//#endregion
export { formatCents as n, routes_exports as t };
