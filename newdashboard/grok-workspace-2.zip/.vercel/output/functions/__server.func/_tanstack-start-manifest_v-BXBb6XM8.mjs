//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BXBb6XM8.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Ca9sLxEp.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Ca9sLxEp.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-IkOGXY9y.js"]
	}
} });
//#endregion
export { tsrStartManifest };
